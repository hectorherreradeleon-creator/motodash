package com.moto.dash

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.UUID

@Suppress("DEPRECATION")
@SuppressLint("MissingPermission")
class MainActivity : Activity() {

    companion object {
        val SVC: UUID = UUID.fromString("0000ff00-0000-1000-8000-00805f9b34fb")
        val CH_NOTIFY: UUID = UUID.fromString("0000ff01-0000-1000-8000-00805f9b34fb")
        val CH_WRITE: UUID = UUID.fromString("0000ff02-0000-1000-8000-00805f9b34fb")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        val CMD_BASIC = byteArrayOf(0xDD.toByte(), 0xA5.toByte(), 0x03, 0x00, 0xFF.toByte(), 0xFD.toByte(), 0x77)
        val CMD_CELLS = byteArrayOf(0xDD.toByte(), 0xA5.toByte(), 0x04, 0x00, 0xFF.toByte(), 0xFC.toByte(), 0x77)
        const val REQ_PERM = 10
    }

    private val ui = Handler(Looper.getMainLooper())

    private val C_BG = Color.parseColor("#0B0F1A")
    private val C_CARD = Color.parseColor("#151B2B")
    private val C_TILE = Color.parseColor("#1F2740")
    private val C_TEXT = Color.parseColor("#F1F5F9")
    private val C_MUTED = Color.parseColor("#8A94A8")
    private val C_LIME = Color.parseColor("#A3E635")
    private val C_CYAN = Color.parseColor("#22D3EE")
    private val C_ORANGE = Color.parseColor("#FB923C")
    private val C_YELLOW = Color.parseColor("#FACC15")
    private val C_RED = Color.parseColor("#F87171")

    private lateinit var dot: View
    private lateinit var tvStatus: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var tvTrip: TextView
    private lateinit var tvMax: TextView
    private lateinit var tvSoc: TextView
    private lateinit var tvCycles: TextView
    private lateinit var barFill: View
    private lateinit var barRest: View
    private lateinit var tvVolt: TextView
    private lateinit var tvVoltSub: TextView
    private lateinit var tvAmp: TextView
    private lateinit var tvAmpSub: TextView
    private lateinit var tvWatt: TextView
    private lateinit var tvWattSub: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvTempSub: TextView
    private lateinit var tvDelta: TextView
    private val cellVal = ArrayList<TextView>()

    private var lm: LocationManager? = null
    private var prevLoc: Location? = null
    private var tripMeters = 0f
    private var maxKmh = 0f
    private var gpsStarted = false

    @Volatile private var tripWh = 0.0
    private var lastKmh = 0f
    private var lastEnergyT = 0L
    private var residualWh = 0.0
    private var curKmh = 0f
    private var curSoc = -1
    private var curVolt = 0.0
    private var curAmp = 0.0
    private var curWatt = 0.0
    private var curDiff = -1
    private var curRange = -1.0
    private var dashMode = false
    private lateinit var portraitRoot: View
    private lateinit var dashRoot: View
    private lateinit var tvRange: TextView
    private lateinit var tvRangeSub: TextView
    private lateinit var tvCons: TextView
    private lateinit var tvConsSub: TextView
    private lateinit var dSpeed: TextView
    private lateinit var dSoc: TextView
    private lateinit var dRange: TextView
    private lateinit var dWatt: TextView
    private lateinit var dVolt: TextView
    private lateinit var dDiff: TextView
    private lateinit var dFill: View
    private lateinit var dRest: View
    private val dCell = ArrayList<TextView>()
    private var curCells = IntArray(0)

    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var connected = false
    private var wantConnected = false
    private var buf = ByteArray(0)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }

    private fun lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(C_CARD, 20)
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun hrow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun statCard(row: LinearLayout, title: String, l: Int, r: Int): Array<TextView> {
        val box = card()
        box.layoutParams = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, l, 0, r, 0)
        val t = tv(12f, C_MUTED); t.text = title
        val v = tv(24f, C_TEXT, true); v.text = "--"
        val s = tv(12f, C_MUTED); s.text = " "
        box.addView(t); box.addView(v); box.addView(s)
        row.addView(box)
        return arrayOf(v, s)
    }

    private fun miniStat(row: LinearLayout, label: String): TextView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val t = tv(12f, C_MUTED); t.text = label
        val v = tv(18f, C_TEXT, true)
        box.addView(t); box.addView(v)
        row.addView(box)
        return v
    }

    private fun setStatus(text: String, color: Int) {
        tvStatus.text = text
        (dot.background as GradientDrawable).setColor(color)
    }

    private fun setBar(soc: Int, color: Int) {
        barFill.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, soc.toFloat())
        barRest.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, (100 - soc).toFloat())
        (barFill.background as GradientDrawable).setColor(color)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(24))
            setBackgroundColor(C_BG)
        }
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C_BG)
        scroll.addView(root)
        setContentView(scroll)
        portraitRoot = scroll
        buildDash()

        // Encabezado
        val header = hrow()
        header.addView(tv(20f, C_TEXT, true).apply {
            text = "MotoDash"
            layoutParams = lp(0, WRAP, 1f)
        })
        dot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C_MUTED) }
            layoutParams = lp(dp(10), dp(10), 0f, 0, 0, 8, 0)
        }
        tvStatus = tv(13f, C_MUTED).apply { text = "Sin conectar" }
        header.addView(dot)
        header.addView(tvStatus)
        root.addView(header, lp(MATCH, WRAP, 0f, 4, 0, 4, 12))

        // Velocidad
        val hero = card()
        tvSpeed = tv(120f, C_TEXT).apply {
            text = "0"
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            includeFontPadding = false
        }
        tvSpeed.setOnClickListener { toggleDash() }
        hero.addView(tvSpeed, lp(MATCH, WRAP))
        hero.addView(tv(15f, C_MUTED).apply { text = "km/h   ·   toca la velocidad para pantalla grande"; gravity = Gravity.CENTER }, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
        val tripRow = hrow()
        tvTrip = miniStat(tripRow, "Viaje"); tvTrip.text = "0.00 km"
        tvMax = miniStat(tripRow, "Máxima"); tvMax.text = "0 km/h"
        tripRow.addView(tv(13f, C_TEXT, true).apply {
            text = "REINICIAR"
            background = rounded(C_TILE, 12)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener {
                saveCons(); tripMeters = 0f; prevLoc = null; maxKmh = 0f; tripWh = 0.0; updateRange()
                tvTrip.text = "0.00 km"; tvMax.text = "0 km/h"
            }
        })
        hero.addView(tripRow, lp(MATCH, WRAP))
        root.addView(hero, lp(MATCH, WRAP))

        // Bateria
        val bat = card()
        val batTop = hrow()
        tvSoc = tv(44f, C_LIME, true).apply { text = "-- %"; layoutParams = lp(0, WRAP, 1f) }
        tvCycles = tv(13f, C_MUTED).apply { text = "Batería"; gravity = Gravity.END }
        batTop.addView(tvSoc); batTop.addView(tvCycles)
        bat.addView(batTop, lp(MATCH, WRAP))
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(C_TILE, 6)
        }
        barFill = View(this).apply {
            background = rounded(C_LIME, 6)
            layoutParams = LinearLayout.LayoutParams(0, MATCH, 0f)
        }
        barRest = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, MATCH, 100f) }
        bar.addView(barFill); bar.addView(barRest)
        bat.addView(bar, lp(MATCH, dp(12), 0f, 0, 8, 0, 0))
        root.addView(bat, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        // Datos
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val volt = statCard(r1, "VOLTAJE", 0, 5); tvVolt = volt[0]; tvVoltSub = volt[1]
        val amp = statCard(r1, "CORRIENTE", 5, 0); tvAmp = amp[0]; tvAmpSub = amp[1]
        root.addView(r1, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val watt = statCard(r2, "POTENCIA", 0, 5); tvWatt = watt[0]; tvWattSub = watt[1]
        val temp = statCard(r2, "TEMPERATURA", 5, 0); tvTemp = temp[0]; tvTemp.textSize = 20f; tvTempSub = temp[1]
        root.addView(r2, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        val r3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rng = statCard(r3, "AUTONOMÍA", 0, 5); tvRange = rng[0]; tvRangeSub = rng[1]
        val cns = statCard(r3, "CONSUMO", 5, 0); tvCons = cns[0]; tvConsSub = cns[1]
        root.addView(r3, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        // Celdas
        val cells = card()
        val cHead = hrow()
        cHead.addView(tv(15f, C_TEXT, true).apply { text = "Celdas"; layoutParams = lp(0, WRAP, 1f) })
        tvDelta = tv(13f, C_MUTED).apply { text = "Diferencia --" }
        cHead.addView(tvDelta)
        cells.addView(cHead, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        var idx = 0
        for (r in 0 until 5) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 4) {
                idx++
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    background = rounded(C_TILE, 12)
                    setPadding(0, dp(7), 0, dp(7))
                }
                tile.addView(tv(10f, C_MUTED).apply { text = "$idx"; gravity = Gravity.CENTER })
                val v = tv(15f, C_TEXT, true).apply { text = "--"; gravity = Gravity.CENTER }
                tile.addView(v)
                cellVal.add(v)
                row.addView(tile, lp(0, WRAP, 1f, 3, 3, 3, 3))
            }
            cells.addView(row, lp(MATCH, WRAP))
        }
        val legend = hrow()
        legend.addView(tv(12f, C_CYAN).apply { text = "● más alta" })
        legend.addView(tv(12f, C_ORANGE).apply { text = "● más baja" }, lp(WRAP, WRAP, 0f, 14, 0, 0, 0))
        cells.addView(legend, lp(MATCH, WRAP, 0f, 4, 6, 0, 0))
        root.addView(cells, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        // Boton
        root.addView(tv(15f, Color.parseColor("#0B0F1A"), true).apply {
            text = "Buscar / elegir BMS"
            gravity = Gravity.CENTER
            background = rounded(C_LIME, 16)
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener { scanAndChoose() }
        }, lp(MATCH, WRAP, 0f, 0, 14, 0, 0))

        if (hasAllPermissions()) {
            startGps()
            connectSaved()
        } else {
            requestPermissions(neededPermissions(), REQ_PERM)
        }
    }

    // ---------- Permisos ----------
    private fun neededPermissions(): Array<String> {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_SCAN)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        return l.toTypedArray()
    }

    private fun hasAllPermissions(): Boolean =
        neededPermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasAllPermissions()) {
            startGps()
            connectSaved()
        } else {
            Toast.makeText(this, "Faltan permisos (ubicacion y Bluetooth)", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- GPS ----------
    private val locListener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            val kmh = if (loc.hasSpeed()) loc.speed * 3.6f else 0f
            val shown = if (kmh < 1.5f) 0f else kmh
            tvSpeed.text = String.format("%.0f", shown)
            lastKmh = shown
            curKmh = shown
            if (shown > maxKmh) {
                maxKmh = shown
                tvMax.text = String.format("%.0f km/h", maxKmh)
            }
            val p = prevLoc
            if (p != null && loc.accuracy < 30f && kmh >= 2f) {
                tripMeters += p.distanceTo(loc)
            }
            prevLoc = loc
            tvTrip.text = String.format("%.2f km", tripMeters / 1000f)
            updateRange()
        }
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private fun startGps() {
        if (gpsStarted) return
        val m = getSystemService(LOCATION_SERVICE) as LocationManager
        lm = m
        if (!m.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(this, "Activa el GPS del telefono", Toast.LENGTH_LONG).show()
        }
        m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener)
        gpsStarted = true
    }

    // ---------- Bluetooth: busqueda ----------
    private fun adapter() = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private fun scanAndChoose() {
        if (!hasAllPermissions()) {
            requestPermissions(neededPermissions(), REQ_PERM)
            return
        }
        val ad = adapter()
        if (ad == null || !ad.isEnabled) {
            Toast.makeText(this, "Enciende el Bluetooth", Toast.LENGTH_LONG).show()
            return
        }
        val scanner = ad.bluetoothLeScanner
        val found = LinkedHashMap<String, Triple<String, Int, String>>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, r: ScanResult) {
                val name = r.scanRecord?.deviceName ?: r.device.name ?: "(sin nombre)"
                found[r.device.address] = Triple(name, r.rssi, r.device.address)
            }
        }
        setStatus("Buscando…", C_YELLOW)
        scanner.startScan(cb)
        ui.postDelayed({
            scanner.stopScan(cb)
            if (connected) setStatus("Conectado", C_LIME) else setStatus("Sin conectar", C_MUTED)
            val list = found.values.sortedByDescending { it.second }
            if (list.isEmpty()) {
                Toast.makeText(this, "No se encontro nada. Cierra Bat BMS e intenta otra vez", Toast.LENGTH_LONG).show()
            } else {
                val labels = list.map { "${it.first}  (${it.third})  ${it.second} dBm" }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("Elige tu BMS")
                    .setItems(labels) { _, i ->
                        getSharedPreferences("moto", 0).edit().putString("addr", list[i].third).apply()
                        connect(list[i].third)
                    }
                    .show()
            }
        }, 6000)
    }

    // ---------- Bluetooth: conexion ----------
    private fun connectSaved() {
        val a = getSharedPreferences("moto", 0).getString("addr", null)
        if (a != null) connect(a)
    }

    private fun connect(addr: String) {
        val ad = adapter() ?: return
        wantConnected = true
        gatt?.close()
        connected = false
        buf = ByteArray(0)
        setStatus("Conectando…", C_YELLOW)
        val dev = ad.getRemoteDevice(addr)
        gatt = dev.connectGatt(this, false, gattCb, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connected = false
                g.close()
                runOnUiThread { setStatus("Desconectado", C_RED) }
                if (wantConnected) {
                    ui.postDelayed({ if (wantConnected && !connected) connectSaved() }, 4000)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val svc = g.getService(SVC)
            val n = svc?.getCharacteristic(CH_NOTIFY)
            val w = svc?.getCharacteristic(CH_WRITE)
            if (n == null || w == null) {
                runOnUiThread { setStatus("No compatible", C_RED) }
                return
            }
            writeChar = w
            g.setCharacteristicNotification(n, true)
            val d = n.getDescriptor(CCCD)
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            connected = true
            runOnUiThread { setStatus("Conectado", C_LIME) }
            ui.post(poll)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val data = c.value ?: return
            synchronized(this@MainActivity) {
                buf += data
                parseFrames()
            }
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            if (!connected) return
            send(CMD_BASIC)
            ui.postDelayed({ send(CMD_CELLS) }, 350)
            ui.postDelayed(this, 1500)
        }
    }

    private fun send(cmd: ByteArray) {
        val g = gatt ?: return
        val w = writeChar ?: return
        w.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        w.value = cmd
        g.writeCharacteristic(w)
    }

    // ---------- Protocolo del BMS ----------
    private fun parseFrames() {
        while (true) {
            val start = buf.indexOfFirst { it == 0xDD.toByte() }
            if (start < 0) { buf = ByteArray(0); return }
            if (start > 0) buf = buf.copyOfRange(start, buf.size)
            if (buf.size < 4) return
            val len = buf[3].toInt() and 0xFF
            val total = len + 7
            if (buf.size < total) return
            val frame = buf.copyOfRange(0, total)
            buf = buf.copyOfRange(total, buf.size)
            if (frame[total - 1] != 0x77.toByte()) continue
            var sum = 0
            for (i in 2 until total - 3) sum += frame[i].toInt() and 0xFF
            val chk = ((0x10000 - sum) and 0xFFFF)
            val got = ((frame[total - 3].toInt() and 0xFF) shl 8) or (frame[total - 2].toInt() and 0xFF)
            if (chk != got) continue
            if (frame[2].toInt() != 0) continue
            val d = frame.copyOfRange(4, 4 + len)
            when (frame[1].toInt() and 0xFF) {
                0x03 -> if (len >= 23) handleBasic(d)
                0x04 -> handleCells(d)
            }
        }
    }

    private fun u16(d: ByteArray, i: Int) = ((d[i].toInt() and 0xFF) shl 8) or (d[i + 1].toInt() and 0xFF)

    private fun handleBasic(d: ByteArray) {
        val volt = u16(d, 0) / 100.0
        val amp = u16(d, 2).toShort().toInt() / 100.0
        val cycles = u16(d, 8)
        val bal = u16(d, 12) != 0 || u16(d, 14) != 0
        val prot = u16(d, 16)
        val soc = d[19].toInt() and 0xFF
        val ntc = d[22].toInt() and 0xFF
        val temps = ArrayList<String>()
        for (k in 0 until ntc) {
            if (23 + 2 * k + 1 < d.size) {
                temps.add(String.format("%.0f", (u16(d, 23 + 2 * k) - 2731) / 10.0))
            }
        }
        val watt = volt * amp
        residualWh = (u16(d, 4) / 100.0) * volt
        val nowT = System.nanoTime()
        if (lastEnergyT != 0L) {
            val dt = (nowT - lastEnergyT) / 1e9
            if (dt in 0.0..5.0 && lastKmh >= 2f) tripWh += -watt * dt / 3600.0
        }
        lastEnergyT = nowT
        curSoc = soc; curVolt = volt; curAmp = amp; curWatt = watt
        val ncell = d[21].toInt() and 0xFF
        val mode = if (amp > 0.05) "Cargando" else if (amp < -0.05) "Descargando" else "En reposo"
        val modeColor = if (amp > 0.05) C_LIME else if (amp < -0.05) C_ORANGE else C_MUTED
        val socColor = if (soc < 15) C_RED else if (soc < 30) C_YELLOW else C_LIME
        runOnUiThread {
            tvSoc.text = "$soc %"
            tvSoc.setTextColor(socColor)
            setBar(soc, socColor)
            tvCycles.text = "$cycles ciclos" + (if (bal) "\nbalanceando" else "")
            tvVolt.text = String.format("%.2f V", volt)
            tvVoltSub.text = "$ncell celdas"
            tvAmp.text = String.format("%.1f A", Math.abs(amp))
            tvAmpSub.text = mode
            tvAmpSub.setTextColor(modeColor)
            tvWatt.text = String.format("%.0f W", Math.abs(watt))
            tvWattSub.text = if (amp > 0.05) "hacia la batería" else if (amp < -0.05) "desde la batería" else "sin consumo"
            tvWattSub.setTextColor(modeColor)
            tvTemp.text = temps.joinToString(" / ") + " °C"
            tvTempSub.text = "$ntc sensores"
            if (prot != 0) setStatus("Protección activa", C_RED) else setStatus("Conectado", C_LIME)
            updateRange()
        }
    }

    private fun handleCells(d: ByteArray) {
        val n = d.size / 2
        val mv = IntArray(n) { u16(d, it * 2) }
        if (mv.isEmpty()) return
        val mn = mv.min()
        val mx = mv.max()
        val diff = mx - mn
        runOnUiThread {
            for (i in 0 until minOf(n, cellVal.size)) {
                val t = cellVal[i]
                t.text = String.format("%.3f", mv[i] / 1000.0)
                t.setTextColor(if (mv[i] == mn) C_ORANGE else if (mv[i] == mx) C_CYAN else C_TEXT)
            }
            tvDelta.text = "Diferencia $diff mV"
            tvDelta.setTextColor(if (diff < 20) C_LIME else if (diff < 50) C_YELLOW else C_RED)
            curDiff = diff
            curCells = mv
            refreshDash()
        }
    }

    // ---------- Autonomia y consumo ----------
    private fun saveCons() {
        val km = tripMeters / 1000f
        if (km >= 1.0f && tripWh > 0) {
            getSharedPreferences("moto", 0).edit().putFloat("whkm", (tripWh / km).toFloat()).apply()
        }
    }

    private fun updateRange() {
        val km = tripMeters / 1000f
        var cons = 0.0
        var src = ""
        if (km >= 0.5f && tripWh > 0) {
            cons = tripWh / km
            src = "este viaje"
        } else {
            val saved = getSharedPreferences("moto", 0).getFloat("whkm", 0f)
            if (saved > 0f) { cons = saved.toDouble(); src = "último viaje" }
        }
        if (cons > 0 && residualWh > 0) {
            curRange = residualWh / cons
            tvRange.text = String.format("%.0f km", curRange)
            tvRangeSub.text = String.format("%.0f Wh restantes", residualWh)
        } else {
            curRange = -1.0
            tvRange.text = "--"
            tvRangeSub.text = "recorre 500 m para calcular"
        }
        if (cons > 0) {
            tvCons.text = String.format("%.1f Wh/km", cons)
            tvConsSub.text = src
        } else {
            tvCons.text = "--"
            tvConsSub.text = "sin datos aún"
        }
        refreshDash()
    }

    // ---------- Pantalla grande (horizontal) ----------
    private fun buildDash() {
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C_BG)
            setPadding(dp(24), dp(10), dp(24), dp(10))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = lp(0, MATCH, 2f)
        }
        dSpeed = tv(150f, C_TEXT).apply {
            text = "0"
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            includeFontPadding = false
        }
        left.addView(dSpeed, lp(MATCH, WRAP))
        left.addView(tv(18f, C_MUTED).apply { text = "km/h"; gravity = Gravity.CENTER }, lp(MATCH, WRAP))

        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(0, MATCH, 1f, 16, 0, 0, 0)
        }
        right.addView(tv(14f, C_MUTED).apply {
            text = "✕ salir"
            gravity = Gravity.END
            setPadding(dp(8), dp(4), dp(8), dp(12))
            setOnClickListener { toggleDash() }
        }, lp(MATCH, WRAP))
        val socRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        dSoc = tv(46f, C_LIME, true).apply { text = "-- %"; layoutParams = lp(0, WRAP, 1f) }
        dVolt = tv(26f, C_TEXT, true).apply { text = "--"; gravity = Gravity.END }
        socRow.addView(dSoc)
        socRow.addView(dVolt)
        right.addView(socRow, lp(MATCH, WRAP))
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(C_TILE, 6)
        }
        dFill = View(this).apply {
            background = rounded(C_LIME, 6)
            layoutParams = LinearLayout.LayoutParams(0, MATCH, 0f)
        }
        dRest = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, MATCH, 100f) }
        bar.addView(dFill); bar.addView(dRest)
        right.addView(bar, lp(MATCH, dp(12), 0f, 0, 6, 0, 14))
        right.addView(tv(12f, C_MUTED).apply { text = "AUTONOMÍA" })
        dRange = tv(30f, C_TEXT, true).apply { text = "--" }
        right.addView(dRange, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
        right.addView(tv(12f, C_MUTED).apply { text = "POTENCIA" })
        dWatt = tv(24f, C_TEXT, true).apply { text = "--" }
        right.addView(dWatt, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
        dDiff = tv(14f, C_MUTED).apply { text = "" }
        right.addView(dDiff, lp(MATCH, WRAP))

        top.addView(left)
        top.addView(right)
        root.addView(top, lp(MATCH, 0, 1f))
        val strip = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (r in 0 until 2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 10) {
                val t = tv(14f, C_TEXT, true).apply {
                    text = "--"
                    gravity = Gravity.CENTER
                    background = rounded(C_TILE, 10)
                    setPadding(0, dp(6), 0, dp(6))
                }
                dCell.add(t)
                row.addView(t, lp(0, WRAP, 1f, 2, 2, 2, 2))
            }
            strip.addView(row, lp(MATCH, WRAP))
        }
        root.addView(strip, lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        dashRoot = root
    }

    private fun refreshDash() {
        if (!dashMode) return
        dSpeed.text = String.format("%.0f", curKmh)
        val col = if (curSoc in 0..14) C_RED else if (curSoc in 15..29) C_YELLOW else C_LIME
        dSoc.text = if (curSoc >= 0) "$curSoc %" else "-- %"
        dSoc.setTextColor(col)
        if (curSoc >= 0) {
            dFill.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, curSoc.toFloat())
            dRest.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, (100 - curSoc).toFloat())
            (dFill.background as GradientDrawable).setColor(col)
        }
        dRange.text = if (curRange >= 0) String.format("%.0f km", curRange) else "--"
        dWatt.text = String.format("%.0f W", Math.abs(curWatt))
        dWatt.setTextColor(if (curAmp > 0.05) C_LIME else if (curAmp < -0.05) C_ORANGE else C_TEXT)
        dVolt.text = String.format("%.1f V", curVolt)
        if (curCells.isNotEmpty()) {
            val mn = curCells.min()
            val mx = curCells.max()
            for (i in 0 until minOf(curCells.size, dCell.size)) {
                dCell[i].text = String.format("%.3f", curCells[i] / 1000.0)
                dCell[i].setTextColor(if (curCells[i] == mn) C_ORANGE else if (curCells[i] == mx) C_CYAN else C_TEXT)
            }
        }
        dDiff.text = if (curDiff >= 0) "Diferencia celdas $curDiff mV" else ""
    }

    private fun toggleDash() {
        dashMode = !dashMode
        if (dashMode) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            setContentView(dashRoot)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            refreshDash()
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            setContentView(portraitRoot)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    override fun onBackPressed() {
        if (dashMode) toggleDash() else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        saveCons()
    }

    override fun onDestroy() {
        super.onDestroy()
        wantConnected = false
        ui.removeCallbacksAndMessages(null)
        try { lm?.removeUpdates(locListener) } catch (e: Exception) {}
        gatt?.close()
    }
}
