package com.moto.dash

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.FrameLayout
import java.io.File
import java.util.UUID
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.cachemanager.CacheManager
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay

@Suppress("DEPRECATION")
@SuppressLint("MissingPermission")
class MainActivity : Activity() {

    companion object {
        val SVC: UUID = UUID.fromString("0000ff00-0000-1000-8000-00805f9b34fb")
        val CH_NOTIFY: UUID = UUID.fromString("0000ff01-0000-1000-8000-00805f9b34fb")
        val CH_WRITE: UUID = UUID.fromString("0000ff02-0000-1000-8000-00805f9b34fb")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        val CMD_BASIC = byteArrayOf(0xDD.toByte(), 0xA5.toByte(), 0x03, 0x00, 0xFF.toByte(), 0xFD.toByte(), 0x77)
        val CMD_CELLS = byteArrayOf(0xDD.toByte(), 0xA5.toByte(), 0x04, 0x00, 0xFF.toByte(), 0xFC.toByte(), 0x77)
        const val REQ_PERM = 10
        val SVC_FFE0: UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb")
        val CH_FFE1: UUID = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb")
        val SVC_FFF0: UUID = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb")
        val CH_FFF1: UUID = UUID.fromString("0000fff1-0000-1000-8000-00805f9b34fb")
        val CH_FFF2: UUID = UUID.fromString("0000fff2-0000-1000-8000-00805f9b34fb")
        fun jkCmd(cmd: Int): ByteArray {
            val f = ByteArray(20)
            f[0] = 0xAA.toByte(); f[1] = 0x55; f[2] = 0x90.toByte(); f[3] = 0xEB.toByte()
            f[4] = cmd.toByte()
            var sum = 0
            for (k in 0 until 19) sum += f[k].toInt() and 0xFF
            f[19] = (sum and 0xFF).toByte()
            return f
        }
        val CMD_JK_INFO = jkCmd(0x97)
        val CMD_JK_CELLS = jkCmd(0x96)
        val CMD_ANT = byteArrayOf(0x7E, 0xA1.toByte(), 0x01, 0x00, 0x00, 0xBE.toByte(), 0x18, 0x55, 0xAA.toByte(), 0x55)
        val CMD_DALY_MB = byteArrayOf(0xD2.toByte(), 0x03, 0x00, 0x00, 0x00, 0x3E, 0xD7.toByte(), 0xB9.toByte())
        val CMD_DALY_UART = byteArrayOf(0xA5.toByte(), 0x40, 0x90.toByte(), 0x08, 0, 0, 0, 0, 0, 0, 0, 0, 0x7D)
    }

    private val ui = Handler(Looper.getMainLooper())

    private val C_BG = Color.parseColor("#05070D")
    private val C_CARD = Color.parseColor("#0D1424")
    private val C_TILE = Color.parseColor("#141D33")
    private val C_TEXT = Color.parseColor("#EAF2FF")
    private val C_MUTED = Color.parseColor("#7C89A6")
    private val C_LIME = Color.parseColor("#9DFF3A")
    private val C_CYAN = Color.parseColor("#00E5FF")
    private val C_ORANGE = Color.parseColor("#FF8A1F")
    private val C_YELLOW = Color.parseColor("#FFD21F")
    private val C_RED = Color.parseColor("#FF4D5E")

    private lateinit var dot: View
    private lateinit var tvStatus: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var gauge: GaugeView
    private lateinit var dGauge: GaugeView
    private lateinit var scaleChip: TextView
    private val barSegs = ArrayList<View>()
    private val dSegs = ArrayList<View>()
    private val scales = floatArrayOf(40f, 60f, 80f, 100f, 120f)
    private lateinit var tvTrip: TextView
    private lateinit var tvMax: TextView
    private lateinit var tvSoc: TextView
    private lateinit var tvCycles: TextView
    private lateinit var barFill: View
    private lateinit var barRest: View
    private lateinit var tvVolt: TextView
    private lateinit var tvVoltSub: TextView
    private lateinit var tvAmp: TextView
    private lateinit var tvAmpSub: TextView
    private lateinit var tvWatt: TextView
    private lateinit var tvWattSub: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvTempSub: TextView
    private lateinit var tvDelta: TextView
    private val cellVal = ArrayList<TextView>()

    private var lm: LocationManager? = null
    private var prevLoc: Location? = null
    private var tripMeters = 0f
    private var maxKmh = 0f
    private var gpsStarted = false

    @Volatile private var tripWh = 0.0
    private var lastKmh = 0f
    private var lastEnergyT = 0L
    private var residualWh = 0.0
    private var movingSec = 0.0
    private var tripStartMs = 0L
    private var lastLocT = 0L
    @Volatile private var tripAh = 0.0
    private var capAh = 0.0
    private lateinit var stAvg: Array<TextView>
    private lateinit var stTime: Array<TextView>
    private lateinit var stPctKm: Array<TextView>
    private lateinit var stPctUsed: Array<TextView>
    private lateinit var stPow: Array<TextView>
    private lateinit var stWh: Array<TextView>
    private var curKmh = 0f
    private var curSoc = -1
    private var curVolt = 0.0
    private var curAmp = 0.0
    private var curWatt = 0.0
    private var curDiff = -1
    private var curRange = -1.0
    private var dashMode = false
    private lateinit var portraitRoot: View
    private lateinit var dashRoot: View
    private lateinit var tvRange: TextView
    private lateinit var tvRangeSub: TextView
    private lateinit var tvCons: TextView
    private lateinit var tvConsSub: TextView
    private lateinit var dSpeed: TextView
    private lateinit var dSoc: TextView
    private lateinit var dRange: TextView
    private lateinit var dWatt: TextView
    private lateinit var dVolt: TextView
    private lateinit var dDiff: TextView
    private lateinit var dFill: View
    private lateinit var dRest: View
    private val dCell = ArrayList<TextView>()
    private var curCells = IntArray(0)
    private lateinit var mapView: MapView
    private lateinit var myLoc: MyLocationNewOverlay
    private lateinit var trackLine: Polyline
    private lateinit var mapHud: TextView
    private lateinit var tabMoto: TextView
    private lateinit var tabMapa: TextView
    private lateinit var motoPage: View
    private lateinit var mapPage: View
    private var mapLocOn = false

    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var connected = false
    private var wantConnected = false
    private var buf = ByteArray(0)
    private var proto = 0
    private var pollCount = 0
    private var lastGoodT = 0L
    private val logSb = StringBuilder()
    private var logT0 = 0L

    inner class GaugeView(ctx: Context) : View(ctx) {
        var speed = 0f
        var maxSpeed = 80f
        var soc = -1
        private var sweep: SweepGradient? = null
        private val pTrack = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.parseColor("#16213A")
        }
        private val pArc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        }
        private val pSoc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        }
        private val pTick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = Color.parseColor("#2A3A5C")
        }
        private val pTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
        private val rect = RectF()

        init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

        fun set(sp: Float, s: Int) {
            speed = sp
            soc = s
            invalidate()
        }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            super.onSizeChanged(w, h, ow, oh)
            sweep = SweepGradient(w / 2f, h / 2f,
                intArrayOf(C_CYAN, C_LIME, C_ORANGE, C_RED, C_RED),
                floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f))
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val cx = w / 2f
            val cy = h / 2f
            val r = minOf(w, h) / 2f - dp(16)
            val sw = r * 0.085f
            pTick.strokeWidth = dp(2).toFloat()
            for (i in 0..27) {
                val len = if (i % 3 == 0) sw * 0.9f else sw * 0.45f
                c.save()
                c.rotate(135f + 270f * i / 27f, cx, cy)
                c.drawLine(cx + r - sw * 1.2f, cy, cx + r - sw * 1.2f - len, cy, pTick)
                c.restore()
            }
            rect.set(cx - r, cy - r, cx + r, cy + r)
            pTrack.strokeWidth = sw
            c.drawArc(rect, 135f, 270f, false, pTrack)
            val f = (speed / maxSpeed).coerceIn(0f, 1f)
            if (f > 0.004f) {
                c.save()
                c.rotate(135f, cx, cy)
                pArc.strokeWidth = sw
                pArc.shader = sweep
                pArc.setShadowLayer(sw * 0.9f, 0f, 0f, if (f < 0.5f) C_CYAN else if (f < 0.8f) C_ORANGE else C_RED)
                c.drawArc(rect, 0f, 270f * f, false, pArc)
                c.restore()
            }
            val r2 = r - sw * 3.6f
            rect.set(cx - r2, cy - r2, cx + r2, cy + r2)
            pTrack.strokeWidth = sw * 0.55f
            c.drawArc(rect, 135f, 270f, false, pTrack)
            if (soc > 0) {
                val sc = if (soc < 15) C_RED else if (soc < 30) C_YELLOW else C_LIME
                pSoc.strokeWidth = sw * 0.55f
                pSoc.color = sc
                pSoc.setShadowLayer(sw * 0.6f, 0f, 0f, sc)
                c.drawArc(rect, 135f, 270f * soc / 100f, false, pSoc)
            }
            pTxt.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            pTxt.color = C_TEXT
            pTxt.textSize = r * 0.62f
            c.drawText(String.format("%.0f", speed), cx, cy + r * 0.20f, pTxt)
            pTxt.typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            pTxt.color = C_MUTED
            pTxt.textSize = r * 0.14f
            c.drawText("KM/H", cx, cy + r * 0.42f, pTxt)
            if (soc >= 0) {
                pTxt.color = if (soc < 15) C_RED else if (soc < 30) C_YELLOW else C_LIME
                pTxt.textSize = r * 0.16f
                c.drawText("BAT $soc%", cx, cy + r * 0.98f, pTxt)
            }
        }
    }

    private fun chipBg(color: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), color)
        }

    private fun tabBg(): GradientDrawable =
        GradientDrawable().apply {
            setColor(Color.parseColor("#0E1A2B"))
            cornerRadius = dp(12).toFloat()
            setStroke(dp(1), C_CYAN)
        }

    private fun fillSegs(list: ArrayList<View>, soc: Int, color: Int) {
        val n = list.size
        for (i in 0 until n) {
            val on = soc * n / 100 > i || (soc > 0 && i == 0)
            (list[i].background as GradientDrawable).setColor(if (on) color else C_TILE)
        }
    }

    private fun cycleScale() {
        val i = scales.indexOfFirst { it == gauge.maxSpeed }
        val n = scales[(i + 1) % scales.size]
        gauge.maxSpeed = n
        dGauge.maxSpeed = n
        gauge.invalidate()
        scaleChip.text = "ESCALA " + n.toInt() + " km/h"
        getSharedPreferences("moto", 0).edit().putFloat("scale", n).apply()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }

    private fun lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#111B30"), Color.parseColor("#0A1020"))).apply {
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.parseColor("#1F3350"))
        }
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun hrow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun statCard(row: LinearLayout, title: String, l: Int, r: Int): Array<TextView> {
        val box = card()
        box.layoutParams = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, l, 0, r, 0)
        val t = tv(11f, C_MUTED); t.text = title; t.letterSpacing = 0.18f
        val v = tv(24f, C_TEXT, true); v.text = "--"
        v.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        val s = tv(12f, C_MUTED); s.text = " "
        box.addView(t); box.addView(v); box.addView(s)
        row.addView(box)
        return arrayOf(v, s)
    }

    private fun miniStat(row: LinearLayout, label: String): TextView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val t = tv(12f, C_MUTED); t.text = label
        val v = tv(18f, C_TEXT, true)
        box.addView(t); box.addView(v)
        row.addView(box)
        return v
    }

    private fun setStatus(text: String, color: Int) {
        tvStatus.text = text
        (dot.background as GradientDrawable).setColor(color)
    }

    private fun setBar(soc: Int, color: Int) {
        fillSegs(barSegs, soc, color)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(24))
            setBackgroundColor(C_BG)
        }
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C_BG)
        scroll.addView(root)
        motoPage = scroll
        buildMapPage()
        val tabs = hrow().apply { setPadding(dp(14), dp(8), dp(14), dp(4)) }
        tabMoto = tv(15f, C_LIME, true).apply {
            text = "MOTO"
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
            setOnClickListener { selectTab(0) }
        }
        tabMapa = tv(15f, C_MUTED, true).apply {
            text = "MAPA"
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
            setOnClickListener { selectTab(1) }
        }
        tabs.addView(tabMoto, lp(0, WRAP, 1f, 0, 0, 4, 0))
        tabs.addView(tabMapa, lp(0, WRAP, 1f, 4, 0, 0, 0))
        val content = FrameLayout(this)
        content.addView(motoPage)
        content.addView(mapPage)
        val appRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C_BG)
        }
        appRoot.addView(tabs, lp(MATCH, WRAP))
        appRoot.addView(content, lp(MATCH, 0, 1f))
        setContentView(appRoot)
        portraitRoot = appRoot
        selectTab(0)
        buildDash()

        // Encabezado
        val header = hrow()
        header.addView(tv(20f, C_TEXT, true).apply {
            text = "MOTODASH"
            letterSpacing = 0.2f
            setTextColor(C_CYAN)
            layoutParams = lp(0, WRAP, 1f)
        })
        dot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C_MUTED) }
            layoutParams = lp(dp(10), dp(10), 0f, 0, 0, 8, 0)
        }
        tvStatus = tv(13f, C_MUTED).apply { text = "Sin conectar" }
        header.addView(dot)
        header.addView(tvStatus)
        root.addView(header, lp(MATCH, WRAP, 0f, 4, 0, 4, 12))

        // Velocidad
        val hero = card()
        val savedScale = getSharedPreferences("moto", 0).getFloat("scale", 80f)
        gauge = GaugeView(this)
        gauge.maxSpeed = savedScale
        dGauge = GaugeView(this)
        dGauge.maxSpeed = savedScale
        gauge.setOnClickListener { toggleDash() }
        hero.addView(gauge, lp(MATCH, dp(300)))
        val chips = hrow()
        chips.gravity = Gravity.CENTER
        scaleChip = tv(12f, C_CYAN, true).apply {
            text = "ESCALA " + savedScale.toInt() + " km/h"
            letterSpacing = 0.1f
            background = chipBg(C_CYAN)
            setPadding(dp(14), dp(7), dp(14), dp(7))
            setOnClickListener { cycleScale() }
        }
        chips.addView(scaleChip)
        chips.addView(tv(12f, C_LIME, true).apply {
            text = "PANTALLA GRANDE"
            letterSpacing = 0.1f
            background = chipBg(C_LIME)
            setPadding(dp(14), dp(7), dp(14), dp(7))
            setOnClickListener { toggleDash() }
        }, lp(WRAP, WRAP, 0f, 10, 0, 0, 0))
        hero.addView(chips, lp(MATCH, WRAP, 0f, 0, 6, 0, 12))
        val tripRow = hrow()
        tvTrip = miniStat(tripRow, "Viaje"); tvTrip.text = "0.00 km"
        tvMax = miniStat(tripRow, "Máxima"); tvMax.text = "0 km/h"
        tripRow.addView(tv(13f, C_TEXT, true).apply {
            text = "REINICIAR"
            background = rounded(C_TILE, 12)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener {
                saveCons(); tripMeters = 0f; prevLoc = null; maxKmh = 0f; tripWh = 0.0; tripAh = 0.0; movingSec = 0.0; tripStartMs = 0L; lastLocT = 0L; trackLine.setPoints(ArrayList<GeoPoint>()); mapView.invalidate(); updateRange()
                tvTrip.text = "0.00 km"; tvMax.text = "0 km/h"
            }
        })
        hero.addView(tripRow, lp(MATCH, WRAP))
        root.addView(hero, lp(MATCH, WRAP))

        // Bateria
        val bat = card()
        val batTop = hrow()
        tvSoc = tv(44f, C_LIME, true).apply { text = "-- %"; layoutParams = lp(0, WRAP, 1f); typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD) }
        tvCycles = tv(13f, C_MUTED).apply { text = "Batería"; gravity = Gravity.END }
        batTop.addView(tvSoc); batTop.addView(tvCycles)
        bat.addView(batTop, lp(MATCH, WRAP))
        val segRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until 20) {
            val v = View(this).apply { background = rounded(C_TILE, 3) }
            barSegs.add(v)
            segRow.addView(v, lp(0, dp(14), 1f, 1, 0, 1, 0))
        }
        bat.addView(segRow, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        root.addView(bat, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        // Datos
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val volt = statCard(r1, "VOLTAJE", 0, 5); tvVolt = volt[0]; tvVoltSub = volt[1]
        val amp = statCard(r1, "CORRIENTE", 5, 0); tvAmp = amp[0]; tvAmpSub = amp[1]
        root.addView(r1, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val watt = statCard(r2, "POTENCIA", 0, 5); tvWatt = watt[0]; tvWattSub = watt[1]
        val temp = statCard(r2, "TEMPERATURA", 5, 0); tvTemp = temp[0]; tvTemp.textSize = 20f; tvTempSub = temp[1]
        root.addView(r2, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        val r3 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rng = statCard(r3, "AUTONOMÍA", 0, 5); tvRange = rng[0]; tvRangeSub = rng[1]
        val cns = statCard(r3, "CONSUMO", 5, 0); tvCons = cns[0]; tvConsSub = cns[1]
        root.addView(r3, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        val r4 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stAvg = statCard(r4, "VEL. PROMEDIO", 0, 5)
        stTime = statCard(r4, "TIEMPO", 5, 0)
        root.addView(r4, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        val r5 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stPctKm = statCard(r5, "BATERÍA POR KM", 0, 5)
        stPctUsed = statCard(r5, "BATERÍA USADA", 5, 0)
        root.addView(r5, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        val r6 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stPow = statCard(r6, "POTENCIA MEDIA", 0, 5)
        stWh = statCard(r6, "ENERGÍA USADA", 5, 0)
        root.addView(r6, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        // Celdas
        val cells = card()
        val cHead = hrow()
        cHead.addView(tv(15f, C_TEXT, true).apply { text = "Celdas"; layoutParams = lp(0, WRAP, 1f) })
        tvDelta = tv(13f, C_MUTED).apply { text = "Diferencia --" }
        cHead.addView(tvDelta)
        cells.addView(cHead, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        var idx = 0
        for (r in 0 until 5) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 4) {
                idx++
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    background = rounded(C_TILE, 12)
                    setPadding(0, dp(7), 0, dp(7))
                }
                tile.addView(tv(10f, C_MUTED).apply { text = "$idx"; gravity = Gravity.CENTER })
                val v = tv(15f, C_TEXT, true).apply { text = "--"; gravity = Gravity.CENTER }
                tile.addView(v)
                cellVal.add(v)
                row.addView(tile, lp(0, WRAP, 1f, 3, 3, 3, 3))
            }
            cells.addView(row, lp(MATCH, WRAP))
        }
        val legend = hrow()
        legend.addView(tv(12f, C_CYAN).apply { text = "● más alta" })
        legend.addView(tv(12f, C_ORANGE).apply { text = "● más baja" }, lp(WRAP, WRAP, 0f, 14, 0, 0, 0))
        cells.addView(legend, lp(MATCH, WRAP, 0f, 4, 6, 0, 0))
        root.addView(cells, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        // Boton
        root.addView(tv(15f, Color.parseColor("#0B0F1A"), true).apply {
            text = "Buscar / elegir BMS"
            gravity = Gravity.CENTER
            background = rounded(C_CYAN, 16)
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener { scanAndChoose() }
        }, lp(MATCH, WRAP, 0f, 0, 14, 0, 0))
        root.addView(tv(14f, C_TEXT, true).apply {
            text = "Compartir registro del BMS"
            gravity = Gravity.CENTER
            background = rounded(C_TILE, 16)
            setPadding(0, dp(12), 0, dp(12))
            setOnClickListener { shareLog() }
        }, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        if (hasAllPermissions()) {
            startGps()
            enableMapLocation()
            connectSaved()
        } else {
            requestPermissions(neededPermissions(), REQ_PERM)
        }
    }

    // ---------- Permisos ----------
    private fun neededPermissions(): Array<String> {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_SCAN)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        return l.toTypedArray()
    }

    private fun hasAllPermissions(): Boolean =
        neededPermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasAllPermissions()) {
            startGps()
            enableMapLocation()
            connectSaved()
        } else {
            Toast.makeText(this, "Faltan permisos (ubicacion y Bluetooth)", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- GPS ----------
    private val locListener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            val kmh = if (loc.hasSpeed()) loc.speed * 3.6f else 0f
            val shown = if (kmh < 1.5f) 0f else kmh
            gauge.speed = shown
            gauge.invalidate()
            lastKmh = shown
            curKmh = shown
            val nowMs = System.currentTimeMillis()
            if (lastLocT != 0L) {
                val dtl = (nowMs - lastLocT) / 1000.0
                if (dtl in 0.0..5.0 && kmh >= 2f) {
                    movingSec += dtl
                    if (tripStartMs == 0L) tripStartMs = nowMs - (dtl * 1000).toLong()
                }
            }
            lastLocT = nowMs
            if (kmh >= 2f) {
                trackLine.addPoint(GeoPoint(loc.latitude, loc.longitude))
                mapView.postInvalidate()
            }
            if (shown > maxKmh) {
                maxKmh = shown
                tvMax.text = String.format("%.0f km/h", maxKmh)
            }
            val p = prevLoc
            if (p != null && loc.accuracy < 30f && kmh >= 2f) {
                tripMeters += p.distanceTo(loc)
            }
            prevLoc = loc
            tvTrip.text = String.format("%.2f km", tripMeters / 1000f)
            updateRange()
        }
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private fun startGps() {
        if (gpsStarted) return
        val m = getSystemService(LOCATION_SERVICE) as LocationManager
        lm = m
        if (!m.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(this, "Activa el GPS del telefono", Toast.LENGTH_LONG).show()
        }
        m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener)
        gpsStarted = true
    }

    // ---------- Bluetooth: busqueda ----------
    private fun adapter() = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private fun scanAndChoose() {
        if (!hasAllPermissions()) {
            requestPermissions(neededPermissions(), REQ_PERM)
            return
        }
        val ad = adapter()
        if (ad == null || !ad.isEnabled) {
            Toast.makeText(this, "Enciende el Bluetooth", Toast.LENGTH_LONG).show()
            return
        }
        val scanner = ad.bluetoothLeScanner
        val found = LinkedHashMap<String, Triple<String, Int, String>>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, r: ScanResult) {
                val name = r.scanRecord?.deviceName ?: r.device.name ?: "(sin nombre)"
                found[r.device.address] = Triple(name, r.rssi, r.device.address)
            }
        }
        setStatus("Buscando…", C_YELLOW)
        scanner.startScan(cb)
        ui.postDelayed({
            scanner.stopScan(cb)
            if (connected) setStatus("Conectado", C_LIME) else setStatus("Sin conectar", C_MUTED)
            val list = found.values.sortedByDescending { it.second }
            if (list.isEmpty()) {
                Toast.makeText(this, "No se encontro nada. Cierra Bat BMS e intenta otra vez", Toast.LENGTH_LONG).show()
            } else {
                val labels = list.map { "${it.first}  (${it.third})  ${it.second} dBm" }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("Elige tu BMS")
                    .setItems(labels) { _, i ->
                        getSharedPreferences("moto", 0).edit().putString("addr", list[i].third).apply()
                        connect(list[i].third)
                    }
                    .show()
            }
        }, 6000)
    }

    // ---------- Bluetooth: conexion ----------
    private fun connectSaved() {
        val a = getSharedPreferences("moto", 0).getString("addr", null)
        if (a != null) connect(a)
    }

    private fun connect(addr: String) {
        val ad = adapter() ?: return
        wantConnected = true
        gatt?.close()
        connected = false
        buf = ByteArray(0)
        proto = 0
        setStatus("Conectando…", C_YELLOW)
        val dev = ad.getRemoteDevice(addr)
        gatt = dev.connectGatt(this, false, gattCb, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connected = false
                g.close()
                runOnUiThread { setStatus("Desconectado", C_RED) }
                if (wantConnected) {
                    ui.postDelayed({ if (wantConnected && !connected) connectSaved() }, 4000)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            synchronized(logSb) { logSb.setLength(0) }
            logT0 = System.nanoTime()
            logLine("Dispositivo: " + g.device.name + " " + g.device.address)
            for (sv in g.services) {
                logLine("Servicio " + sv.uuid)
                for (ch in sv.characteristics) logLine("  Caracteristica " + ch.uuid + " props=" + ch.properties)
            }
            var n: BluetoothGattCharacteristic? = null
            var w: BluetoothGattCharacteristic? = null
            val jbd = g.getService(SVC)
            val jk = g.getService(SVC_FFE0)
            val daly = g.getService(SVC_FFF0)
            if (jbd != null && jbd.getCharacteristic(CH_NOTIFY) != null && jbd.getCharacteristic(CH_WRITE) != null) {
                proto = 1
                n = jbd.getCharacteristic(CH_NOTIFY)
                w = jbd.getCharacteristic(CH_WRITE)
            } else if (jk != null && jk.getCharacteristic(CH_FFE1) != null) {
                proto = 2
                n = jk.getCharacteristic(CH_FFE1)
                w = n
            } else if (daly != null && daly.getCharacteristic(CH_FFF1) != null && daly.getCharacteristic(CH_FFF2) != null) {
                proto = 3
                n = daly.getCharacteristic(CH_FFF1)
                w = daly.getCharacteristic(CH_FFF2)
            }
            if (n == null || w == null) {
                runOnUiThread { setStatus("BMS no reconocido", C_RED) }
                return
            }
            logLine("Protocolo elegido: " + proto)
            writeChar = w
            g.setCharacteristicNotification(n, true)
            val d = n.getDescriptor(CCCD)
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            connected = true
            pollCount = 0
            lastGoodT = 0L
            runOnUiThread {
                if (proto == 3) setStatus("Daly detectado: aún sin soporte", C_YELLOW)
                else setStatus("Conectado", C_LIME)
            }
            if (proto == 2) send(CMD_JK_INFO)
            ui.post(poll)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val data = c.value ?: return
            logLine(String.format("t=%.2f RX %s", (System.nanoTime() - logT0) / 1e9, hex(data)))
            synchronized(this@MainActivity) {
                if (proto == 1) {
                    buf += data
                    parseFrames()
                } else if (proto == 2) {
                    buf += data
                    parseJk()
                } else {
                    buf = ByteArray(0)
                }
            }
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            if (!connected) return
            pollCount++
            if (proto == 1) {
                send(CMD_BASIC)
                ui.postDelayed({ send(CMD_CELLS) }, 350)
            } else if (proto == 2) {
                send(CMD_JK_CELLS)
                if (lastGoodT == 0L && pollCount > 4) {
                    setStatus("Sin datos JK: ¿ANT u otro? comparte el registro", C_YELLOW)
                    ui.postDelayed({ send(CMD_ANT) }, 500)
                }
            } else if (proto == 3) {
                send(if (pollCount % 2 == 0) CMD_DALY_MB else CMD_DALY_UART)
            }
            ui.postDelayed(this, 1500)
        }
    }

    private fun send(cmd: ByteArray) {
        val g = gatt ?: return
        val w = writeChar ?: return
        logLine(String.format("t=%.2f TX %s", (System.nanoTime() - logT0) / 1e9, hex(cmd)))
        w.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        w.value = cmd
        g.writeCharacteristic(w)
    }

    private fun logLine(s: String) {
        synchronized(logSb) {
            if (logSb.length < 90000) logSb.append(s).append('\n')
        }
    }

    private fun hex(b: ByteArray): String {
        val sb = StringBuilder()
        for (x in b) sb.append(String.format("%02X", x.toInt() and 0xFF))
        return sb.toString()
    }

    private fun shareLog() {
        val txt = synchronized(logSb) { logSb.toString() }
        if (txt.isEmpty()) {
            Toast.makeText(this, "Aún no hay datos. Conecta un BMS primero", Toast.LENGTH_LONG).show()
            return
        }
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_SUBJECT, "Registro BMS MotoDash")
        i.putExtra(Intent.EXTRA_TEXT, txt)
        startActivity(Intent.createChooser(i, "Compartir registro"))
    }

    // ---------- JK BMS ----------
    private fun le(f: ByteArray, i: Int, n: Int): Long {
        var v = 0L
        for (k in n - 1 downTo 0) v = (v shl 8) or (f[i + k].toLong() and 0xFF)
        return v
    }

    private fun parseJk() {
        while (true) {
            var i = -1
            for (k in 0..buf.size - 4) {
                if (buf[k] == 0x55.toByte() && buf[k + 1] == 0xAA.toByte() && buf[k + 2] == 0xEB.toByte() && buf[k + 3] == 0x90.toByte()) {
                    i = k
                    break
                }
            }
            if (i < 0) {
                if (buf.size > 600) buf = ByteArray(0)
                return
            }
            if (i > 0) buf = buf.copyOfRange(i, buf.size)
            if (buf.size < 300) return
            val fr = buf.copyOfRange(0, 300)
            buf = buf.copyOfRange(300, buf.size)
            var sum = 0
            for (k in 0 until 299) sum += fr[k].toInt() and 0xFF
            if ((sum and 0xFF) != (fr[299].toInt() and 0xFF)) continue
            if (fr[4].toInt() == 0x02) decodeJk(fr)
        }
    }

    private fun decodeJk(f: ByteArray) {
        val cells = ArrayList<Int>()
        for (i in 0 until 32) {
            val v = le(f, 6 + 2 * i, 2).toInt()
            if (v < 1500 || v > 4800) break
            cells.add(v)
        }
        if (cells.isEmpty()) return
        val sumV = cells.sum() / 1000.0
        val v32 = le(f, 150, 4) / 1000.0
        val v24 = le(f, 118, 4) / 1000.0
        val off = if (Math.abs(v32 - sumV) <= Math.abs(v24 - sumV)) 0 else -32
        val volt = le(f, 150 + off, 4) / 1000.0
        val amp = le(f, 158 + off, 4).toInt() / 1000.0
        val soc = f[173 + off].toInt() and 0xFF
        val resAh = le(f, 174 + off, 4) / 1000.0
        val cycles = le(f, 182 + off, 4).toInt()
        val temps = ArrayList<String>()
        for (idx in intArrayOf(144 + off, 162 + off, 164 + off)) {
            val t = le(f, idx, 2).toShort() / 10.0
            if (t > -40.0 && t < 125.0) temps.add(String.format("%.0f", t))
        }
        lastGoodT = System.nanoTime()
        showBasic(volt, amp, soc, resAh, cycles, false, 0, cells.size, temps)
        showCells(cells.toIntArray())
    }

    // ---------- Protocolo del BMS ----------
    private fun parseFrames() {
        while (true) {
            val start = buf.indexOfFirst { it == 0xDD.toByte() }
            if (start < 0) { buf = ByteArray(0); return }
            if (start > 0) buf = buf.copyOfRange(start, buf.size)
            if (buf.size < 4) return
            val len = buf[3].toInt() and 0xFF
            val total = len + 7
            if (buf.size < total) return
            val frame = buf.copyOfRange(0, total)
            buf = buf.copyOfRange(total, buf.size)
            if (frame[total - 1] != 0x77.toByte()) continue
            var sum = 0
            for (i in 2 until total - 3) sum += frame[i].toInt() and 0xFF
            val chk = ((0x10000 - sum) and 0xFFFF)
            val got = ((frame[total - 3].toInt() and 0xFF) shl 8) or (frame[total - 2].toInt() and 0xFF)
            if (chk != got) continue
            if (frame[2].toInt() != 0) continue
            val d = frame.copyOfRange(4, 4 + len)
            when (frame[1].toInt() and 0xFF) {
                0x03 -> if (len >= 23) handleBasic(d)
                0x04 -> handleCells(d)
            }
        }
    }

    private fun u16(d: ByteArray, i: Int) = ((d[i].toInt() and 0xFF) shl 8) or (d[i + 1].toInt() and 0xFF)

    private fun handleBasic(d: ByteArray) {
        val volt = u16(d, 0) / 100.0
        val amp = u16(d, 2).toShort().toInt() / 100.0
        val cycles = u16(d, 8)
        val bal = u16(d, 12) != 0 || u16(d, 14) != 0
        val prot = u16(d, 16)
        val soc = d[19].toInt() and 0xFF
        val ntc = d[22].toInt() and 0xFF
        val temps = ArrayList<String>()
        for (k in 0 until ntc) {
            if (23 + 2 * k + 1 < d.size) {
                temps.add(String.format("%.0f", (u16(d, 23 + 2 * k) - 2731) / 10.0))
            }
        }
        showBasic(volt, amp, soc, u16(d, 4) / 100.0, cycles, bal, prot, d[21].toInt() and 0xFF, temps)
    }

    private fun showBasic(volt: Double, amp: Double, soc: Int, resAh: Double, cycles: Int,
                          bal: Boolean, prot: Int, ncell: Int, temps: List<String>) {
        val watt = volt * amp
        residualWh = resAh * volt
        val nowT = System.nanoTime()
        if (lastEnergyT != 0L) {
            val dt = (nowT - lastEnergyT) / 1e9
            if (dt in 0.0..5.0 && lastKmh >= 2f) {
                tripWh += -watt * dt / 3600.0
                tripAh += -amp * dt / 3600.0
            }
        }
        lastEnergyT = nowT
        if (soc >= 10 && resAh > 0) capAh = resAh * 100.0 / soc
        curSoc = soc; curVolt = volt; curAmp = amp; curWatt = watt
        val mode = if (amp > 0.05) "Cargando" else if (amp < -0.05) "Descargando" else "En reposo"
        val modeColor = if (amp > 0.05) C_LIME else if (amp < -0.05) C_ORANGE else C_MUTED
        val socColor = if (soc < 15) C_RED else if (soc < 30) C_YELLOW else C_LIME
        runOnUiThread {
            tvSoc.text = "$soc %"
            tvSoc.setTextColor(socColor)
            setBar(soc, socColor)
            gauge.soc = soc
            gauge.invalidate()
            tvCycles.text = "$cycles ciclos" + (if (bal) "\nbalanceando" else "")
            tvVolt.text = String.format("%.2f V", volt)
            tvVoltSub.text = "$ncell celdas"
            tvAmp.text = String.format("%.1f A", Math.abs(amp))
            tvAmpSub.text = mode
            tvAmpSub.setTextColor(modeColor)
            tvWatt.text = String.format("%.0f W", Math.abs(watt))
            tvWattSub.text = if (amp > 0.05) "hacia la batería" else if (amp < -0.05) "desde la batería" else "sin consumo"
            tvWattSub.setTextColor(modeColor)
            tvTemp.text = temps.joinToString(" / ") + " °C"
            tvTempSub.text = "${temps.size} sensores"
            if (prot != 0) setStatus("Protección activa", C_RED) else setStatus("Conectado", C_LIME)
            updateRange()
        }
    }

    private fun handleCells(d: ByteArray) {
        showCells(IntArray(d.size / 2) { u16(d, it * 2) })
    }

    private fun showCells(mv: IntArray) {
        val n = mv.size
        if (n == 0) return
        val mn = mv.min()
        val mx = mv.max()
        val diff = mx - mn
        runOnUiThread {
            for (i in 0 until minOf(n, cellVal.size)) {
                val t = cellVal[i]
                t.text = String.format("%.3f", mv[i] / 1000.0)
                t.setTextColor(if (mv[i] == mn) C_ORANGE else if (mv[i] == mx) C_CYAN else C_TEXT)
            }
            tvDelta.text = "Diferencia $diff mV"
            tvDelta.setTextColor(if (diff < 20) C_LIME else if (diff < 50) C_YELLOW else C_RED)
            curDiff = diff
            curCells = mv
            refreshDash()
        }
    }

    // ---------- Mapa ----------
    private fun selectTab(i: Int) {
        motoPage.visibility = if (i == 0) View.VISIBLE else View.GONE
        mapPage.visibility = if (i == 1) View.VISIBLE else View.GONE
        tabMoto.setTextColor(if (i == 0) C_CYAN else C_MUTED)
        tabMapa.setTextColor(if (i == 1) C_CYAN else C_MUTED)
        tabMoto.background = if (i == 0) tabBg() else null
        tabMapa.background = if (i == 1) tabBg() else null
    }

    private fun enableMapLocation() {
        if (!mapLocOn && hasAllPermissions()) {
            myLoc.enableMyLocation()
            myLoc.enableFollowLocation()
            mapLocOn = true
        }
    }

    private fun refreshHud() {
        val soc = if (curSoc >= 0) "$curSoc %" else "-- %"
        val rng = if (curRange >= 0) String.format("  ·  %.0f km", curRange) else ""
        mapHud.text = String.format("%.0f km/h", curKmh) + "  ·  " + soc + rng
    }

    private fun buildMapPage() {
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        val cfg = Configuration.getInstance()
        cfg.load(applicationContext, getSharedPreferences("osm", 0))
        cfg.userAgentValue = packageName
        cfg.osmdroidBasePath = File(filesDir, "osmdroid")
        cfg.osmdroidTileCache = File(filesDir, "osmdroid/tiles")
        cfg.tileFileSystemCacheMaxBytes = 2000000000L
        cfg.tileFileSystemCacheTrimBytes = 1800000000L

        val page = FrameLayout(this)
        mapView = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(3.0)
        }
        trackLine = Polyline().apply {
            outlinePaint.color = C_CYAN
            outlinePaint.strokeWidth = 9f
        }
        mapView.overlays.add(trackLine)
        myLoc = MyLocationNewOverlay(GpsMyLocationProvider(this), mapView)
        myLoc.runOnFirstFix {
            runOnUiThread {
                val here = myLoc.myLocation
                if (here != null) {
                    mapView.controller.setZoom(16.0)
                    mapView.controller.setCenter(here)
                }
            }
        }
        mapView.overlays.add(myLoc)
        page.addView(mapView, FrameLayout.LayoutParams(MATCH, MATCH))

        mapHud = tv(16f, C_TEXT, true).apply {
            text = "0 km/h  ·  -- %"
            background = rounded(Color.argb(215, 11, 15, 26), 14)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        page.addView(mapHud, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply {
            setMargins(dp(10), dp(10), 0, 0)
        })

        val btnC = tv(14f, Color.parseColor("#0B0F1A"), true).apply {
            text = "Centrar"
            background = rounded(C_LIME, 14)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnClickListener {
                myLoc.enableFollowLocation()
                if (mapView.zoomLevelDouble < 15.0) mapView.controller.setZoom(16.0)
            }
        }
        page.addView(btnC, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(12), dp(16))
        })
        val btnS = tv(14f, C_TEXT, true).apply {
            text = "Guardar zona"
            background = rounded(Color.argb(235, 31, 39, 64), 14)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnClickListener { saveArea() }
        }
        page.addView(btnS, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(12), 0, 0, dp(16))
        })
        mapPage = page
    }

    private fun saveArea() {
        val bb = mapView.boundingBox
        val z = mapView.zoomLevelDouble.toInt()
        val zMin = maxOf(z, 8)
        val zMax = minOf(z + 2, 17)
        val cm = CacheManager(mapView)
        val n = cm.possibleTilesInArea(bb, zMin, zMax)
        if (n > 3000) {
            Toast.makeText(this, "Zona muy grande ($n mapas). Acércate más (máximo 3000).", Toast.LENGTH_LONG).show()
            return
        }
        val mb = n * 15 / 1024
        AlertDialog.Builder(this)
            .setTitle("Guardar zona sin internet")
            .setMessage("Se descargarán unos $n mapas (≈ $mb MB) de lo que ves ahora, con 3 niveles de zoom. Necesitas internet en este momento.")
            .setPositiveButton("Guardar") { _, _ ->
                cm.downloadAreaAsync(this, bb, zMin, zMax, object : CacheManager.CacheManagerCallback {
                    override fun onTaskComplete() {
                        runOnUiThread { Toast.makeText(this@MainActivity, "Zona guardada para usar sin internet", Toast.LENGTH_LONG).show() }
                    }
                    override fun onTaskFailed(errors: Int) {
                        runOnUiThread { Toast.makeText(this@MainActivity, "Terminó con $errors errores", Toast.LENGTH_LONG).show() }
                    }
                    override fun updateProgress(progress: Int, currentZoomLevel: Int, zoomMin: Int, zoomMax: Int) {}
                    override fun downloadStarted() {}
                    override fun setPossibleTilesInArea(total: Int) {}
                })
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Autonomia y consumo ----------
    private fun fmtTime(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val sc = sec % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sc) else String.format("%02d:%02d", m, sc)
    }

    private fun updateStats() {
        val km = tripMeters / 1000f
        val movingH = movingSec / 3600.0
        val avg = if (movingH > 0.0008 && km > 0.05f) km / movingH else 0.0
        val elapsed = if (tripStartMs > 0L) (System.currentTimeMillis() - tripStartMs) / 1000 else 0L
        stAvg[0].text = if (avg > 0) String.format("%.1f km/h", avg) else "--"
        stAvg[1].text = "solo en movimiento"
        stTime[0].text = fmtTime(movingSec.toLong())
        stTime[1].text = "total " + fmtTime(elapsed)
        val usedPct = if (capAh > 0) tripAh / capAh * 100.0 else 0.0
        if (km >= 0.3f && usedPct > 0.05) {
            stPctKm[0].text = String.format("%.2f %%/km", usedPct / km)
            stPctKm[1].text = String.format("≈ %.1f km por 1 %%", km / usedPct)
        } else {
            stPctKm[0].text = "--"
            stPctKm[1].text = "recorre 300 m para calcular"
        }
        stPctUsed[0].text = if (tripAh > 0) String.format("%.1f %%", usedPct) else "--"
        stPctUsed[1].text = String.format("%.1f Ah", Math.max(tripAh, 0.0))
        stPow[0].text = if (movingH > 0.0008 && tripWh > 0) String.format("%.0f W", tripWh / movingH) else "--"
        stPow[1].text = "al avanzar"
        stWh[0].text = if (tripWh > 0) String.format("%.0f Wh", tripWh) else "--"
        stWh[1].text = "energía neta del viaje"
    }

    private fun saveCons() {
        val km = tripMeters / 1000f
        if (km >= 1.0f && tripWh > 0) {
            getSharedPreferences("moto", 0).edit().putFloat("whkm", (tripWh / km).toFloat()).apply()
        }
    }

    private fun updateRange() {
        val km = tripMeters / 1000f
        var cons = 0.0
        var src = ""
        if (km >= 0.5f && tripWh > 0) {
            cons = tripWh / km
            src = "este viaje"
        } else {
            val saved = getSharedPreferences("moto", 0).getFloat("whkm", 0f)
            if (saved > 0f) { cons = saved.toDouble(); src = "último viaje" }
        }
        if (cons > 0 && residualWh > 0) {
            curRange = residualWh / cons
            tvRange.text = String.format("%.0f km", curRange)
            tvRangeSub.text = String.format("%.0f Wh restantes", residualWh)
        } else {
            curRange = -1.0
            tvRange.text = "--"
            tvRangeSub.text = "recorre 500 m para calcular"
        }
        if (cons > 0) {
            tvCons.text = String.format("%.1f Wh/km", cons)
            tvConsSub.text = src
        } else {
            tvCons.text = "--"
            tvConsSub.text = "sin datos aún"
        }
        updateStats()
        refreshHud()
        refreshDash()
    }

    // ---------- Pantalla grande (horizontal) ----------
    private fun buildDash() {
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C_BG)
            setPadding(dp(24), dp(10), dp(24), dp(10))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = lp(0, MATCH, 2f)
        }
        left.addView(dGauge, lp(MATCH, MATCH))

        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = lp(0, MATCH, 1f, 16, 0, 0, 0)
        }
        right.addView(tv(14f, C_MUTED).apply {
            text = "✕ salir"
            gravity = Gravity.END
            setPadding(dp(8), dp(4), dp(8), dp(12))
            setOnClickListener { toggleDash() }
        }, lp(MATCH, WRAP))
        val socRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        dSoc = tv(46f, C_LIME, true).apply { text = "-- %"; layoutParams = lp(0, WRAP, 1f) }
        dVolt = tv(26f, C_TEXT, true).apply { text = "--"; gravity = Gravity.END }
        socRow.addView(dSoc)
        socRow.addView(dVolt)
        right.addView(socRow, lp(MATCH, WRAP))
        val dSegRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until 20) {
            val v = View(this).apply { background = rounded(C_TILE, 3) }
            dSegs.add(v)
            dSegRow.addView(v, lp(0, dp(12), 1f, 1, 0, 1, 0))
        }
        right.addView(dSegRow, lp(MATCH, WRAP, 0f, 0, 6, 0, 14))
        right.addView(tv(12f, C_MUTED).apply { text = "AUTONOMÍA" })
        dRange = tv(30f, C_TEXT, true).apply { text = "--" }
        right.addView(dRange, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
        right.addView(tv(12f, C_MUTED).apply { text = "POTENCIA" })
        dWatt = tv(24f, C_TEXT, true).apply { text = "--" }
        right.addView(dWatt, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
        dDiff = tv(14f, C_MUTED).apply { text = "" }
        right.addView(dDiff, lp(MATCH, WRAP))

        top.addView(left)
        top.addView(right)
        root.addView(top, lp(MATCH, 0, 1f))
        val strip = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (r in 0 until 2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 10) {
                val t = tv(14f, C_TEXT, true).apply {
                    text = "--"
                    gravity = Gravity.CENTER
                    background = rounded(C_TILE, 10)
                    setPadding(0, dp(6), 0, dp(6))
                }
                dCell.add(t)
                row.addView(t, lp(0, WRAP, 1f, 2, 2, 2, 2))
            }
            strip.addView(row, lp(MATCH, WRAP))
        }
        root.addView(strip, lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        dashRoot = root
    }

    private fun refreshDash() {
        if (!dashMode) return
        dGauge.set(curKmh, curSoc)
        val col = if (curSoc in 0..14) C_RED else if (curSoc in 15..29) C_YELLOW else C_LIME
        dSoc.text = if (curSoc >= 0) "$curSoc %" else "-- %"
        dSoc.setTextColor(col)
        if (curSoc >= 0) {
            fillSegs(dSegs, curSoc, col)
        }
        dRange.text = if (curRange >= 0) String.format("%.0f km", curRange) else "--"
        dWatt.text = String.format("%.0f W", Math.abs(curWatt))
        dWatt.setTextColor(if (curAmp > 0.05) C_LIME else if (curAmp < -0.05) C_ORANGE else C_TEXT)
        dVolt.text = String.format("%.1f V", curVolt)
        if (curCells.isNotEmpty()) {
            val mn = curCells.min()
            val mx = curCells.max()
            for (i in 0 until minOf(curCells.size, dCell.size)) {
                dCell[i].text = String.format("%.3f", curCells[i] / 1000.0)
                dCell[i].setTextColor(if (curCells[i] == mn) C_ORANGE else if (curCells[i] == mx) C_CYAN else C_TEXT)
            }
        }
        dDiff.text = if (curDiff >= 0) "Diferencia celdas $curDiff mV" else ""
    }

    private fun toggleDash() {
        dashMode = !dashMode
        if (dashMode) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            setContentView(dashRoot)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            refreshDash()
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            setContentView(portraitRoot)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    override fun onBackPressed() {
        if (dashMode) toggleDash() else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        saveCons()
        mapView.onPause()
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onDestroy() {
        super.onDestroy()
        wantConnected = false
        ui.removeCallbacksAndMessages(null)
        try { lm?.removeUpdates(locListener) } catch (e: Exception) {}
        gatt?.close()
    }
}
