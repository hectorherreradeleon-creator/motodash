package com.moto.dash

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.UUID

@Suppress("DEPRECATION")
@SuppressLint("MissingPermission")
class MainActivity : Activity() {

    companion object {
        val SVC: UUID = UUID.fromString("0000ff00-0000-1000-8000-00805f9b34fb")
        val CH_NOTIFY: UUID = UUID.fromString("0000ff01-0000-1000-8000-00805f9b34fb")
        val CH_WRITE: UUID = UUID.fromString("0000ff02-0000-1000-8000-00805f9b34fb")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        val CMD_BASIC = byteArrayOf(0xDD.toByte(), 0xA5.toByte(), 0x03, 0x00, 0xFF.toByte(), 0xFD.toByte(), 0x77)
        val CMD_CELLS = byteArrayOf(0xDD.toByte(), 0xA5.toByte(), 0x04, 0x00, 0xFF.toByte(), 0xFC.toByte(), 0x77)
        const val REQ_PERM = 10
    }

    private val ui = Handler(Looper.getMainLooper())

    // Vistas
    private lateinit var tvStatus: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var tvTrip: TextView
    private lateinit var tvSoc: TextView
    private lateinit var tvVolt: TextView
    private lateinit var tvAmp: TextView
    private lateinit var tvWatt: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvDelta: TextView
    private val cellViews = ArrayList<TextView>()

    // GPS
    private var lm: LocationManager? = null
    private var prevLoc: Location? = null
    private var tripMeters = 0f
    private var gpsStarted = false

    // Bluetooth
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var connected = false
    private var wantConnected = false
    private var buf = ByteArray(0)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun infoBox(row: LinearLayout, title: String): TextView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val t = tv(12f, Color.GRAY)
        t.text = title
        val v = tv(22f, Color.WHITE, true)
        v.text = "--"
        box.addView(t)
        box.addView(v)
        row.addView(box)
        return v
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
            setBackgroundColor(Color.BLACK)
        }
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.addView(root)
        setContentView(scroll)

        tvStatus = tv(13f, Color.GRAY).apply { text = "BMS: sin conectar" }
        root.addView(tvStatus)

        tvSpeed = tv(96f, Color.WHITE, true).apply {
            text = "0"
            gravity = Gravity.CENTER
        }
        root.addView(tvSpeed)
        root.addView(tv(16f, Color.GRAY).apply {
            text = "km/h"
            gravity = Gravity.CENTER
        })

        val tripRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        tvTrip = tv(18f, Color.WHITE).apply {
            text = "Viaje: 0.00 km"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val btnReset = Button(this).apply {
            text = "Reiniciar"
            setOnClickListener {
                tripMeters = 0f
                prevLoc = null
                tvTrip.text = "Viaje: 0.00 km"
            }
        }
        tripRow.addView(tvTrip)
        tripRow.addView(btnReset)
        root.addView(tripRow)

        tvSoc = tv(56f, Color.rgb(120, 200, 80), true).apply {
            text = "-- %"
            gravity = Gravity.CENTER
        }
        root.addView(tvSoc)

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tvVolt = infoBox(row1, "Voltaje total")
        tvAmp = infoBox(row1, "Corriente")
        root.addView(row1)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tvWatt = infoBox(row2, "Potencia")
        tvTemp = infoBox(row2, "Temperaturas")
        root.addView(row2)

        tvDelta = tv(16f, Color.WHITE).apply {
            text = "Diferencia entre celdas: --"
            setPadding(dp(8), dp(16), dp(8), dp(8))
        }
        root.addView(tvDelta)

        var idx = 0
        for (r in 0 until 5) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 4) {
                idx++
                val cell = tv(14f, Color.DKGRAY).apply {
                    text = "$idx\n--"
                    gravity = Gravity.CENTER
                    setPadding(0, dp(6), 0, dp(6))
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                cellViews.add(cell)
                row.addView(cell)
            }
            root.addView(row)
        }

        val btnBms = Button(this).apply {
            text = "Buscar / elegir BMS"
            setOnClickListener { scanAndChoose() }
        }
        root.addView(btnBms)

        if (hasAllPermissions()) {
            startGps()
            connectSaved()
        } else {
            requestPermissions(neededPermissions(), REQ_PERM)
        }
    }

    // ---------- Permisos ----------
    private fun neededPermissions(): Array<String> {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_SCAN)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        return l.toTypedArray()
    }

    private fun hasAllPermissions(): Boolean =
        neededPermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasAllPermissions()) {
            startGps()
            connectSaved()
        } else {
            Toast.makeText(this, "Faltan permisos (ubicacion y Bluetooth)", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- GPS ----------
    private val locListener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            val kmh = if (loc.hasSpeed()) loc.speed * 3.6f else 0f
            val shown = if (kmh < 1.5f) 0f else kmh
            tvSpeed.text = String.format("%.0f", shown)
            val p = prevLoc
            if (p != null && loc.accuracy < 30f && kmh >= 2f) {
                tripMeters += p.distanceTo(loc)
            }
            prevLoc = loc
            tvTrip.text = String.format("Viaje: %.2f km", tripMeters / 1000f)
        }
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private fun startGps() {
        if (gpsStarted) return
        val m = getSystemService(LOCATION_SERVICE) as LocationManager
        lm = m
        if (!m.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(this, "Activa el GPS del telefono", Toast.LENGTH_LONG).show()
        }
        m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener)
        gpsStarted = true
    }

    // ---------- Bluetooth: busqueda ----------
    private fun adapter() = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private fun scanAndChoose() {
        if (!hasAllPermissions()) {
            requestPermissions(neededPermissions(), REQ_PERM)
            return
        }
        val ad = adapter()
        if (ad == null || !ad.isEnabled) {
            Toast.makeText(this, "Enciende el Bluetooth", Toast.LENGTH_LONG).show()
            return
        }
        val scanner = ad.bluetoothLeScanner
        val found = LinkedHashMap<String, Triple<String, Int, String>>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, r: ScanResult) {
                val name = r.scanRecord?.deviceName ?: r.device.name ?: "(sin nombre)"
                found[r.device.address] = Triple(name, r.rssi, r.device.address)
            }
        }
        tvStatus.text = "Buscando dispositivos (6 s)... acerca el telefono a la moto"
        scanner.startScan(cb)
        ui.postDelayed({
            scanner.stopScan(cb)
            tvStatus.text = "BMS: sin conectar"
            val list = found.values.sortedByDescending { it.second }
            if (list.isEmpty()) {
                Toast.makeText(this, "No se encontro nada. Cierra Bat BMS e intenta otra vez", Toast.LENGTH_LONG).show()
            } else {
                val labels = list.map { "${it.first}  (${it.third})  ${it.second} dBm" }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("Elige tu BMS")
                    .setItems(labels) { _, i ->
                        getSharedPreferences("moto", 0).edit().putString("addr", list[i].third).apply()
                        connect(list[i].third)
                    }
                    .show()
            }
        }, 6000)
    }

    // ---------- Bluetooth: conexion ----------
    private fun connectSaved() {
        val a = getSharedPreferences("moto", 0).getString("addr", null)
        if (a != null) connect(a)
    }

    private fun connect(addr: String) {
        val ad = adapter() ?: return
        wantConnected = true
        gatt?.close()
        connected = false
        buf = ByteArray(0)
        tvStatus.text = "BMS: conectando..."
        val dev = ad.getRemoteDevice(addr)
        gatt = dev.connectGatt(this, false, gattCb, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connected = false
                g.close()
                runOnUiThread { tvStatus.text = "BMS: desconectado (reintentando...)" }
                if (wantConnected) {
                    ui.postDelayed({ if (wantConnected && !connected) connectSaved() }, 4000)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val svc = g.getService(SVC)
            val n = svc?.getCharacteristic(CH_NOTIFY)
            val w = svc?.getCharacteristic(CH_WRITE)
            if (n == null || w == null) {
                runOnUiThread { tvStatus.text = "BMS: este dispositivo no es compatible" }
                return
            }
            writeChar = w
            g.setCharacteristicNotification(n, true)
            val d = n.getDescriptor(CCCD)
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            connected = true
            runOnUiThread { tvStatus.text = "BMS: conectado" }
            ui.post(poll)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val data = c.value ?: return
            synchronized(this@MainActivity) {
                buf += data
                parseFrames()
            }
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            if (!connected) return
            send(CMD_BASIC)
            ui.postDelayed({ send(CMD_CELLS) }, 350)
            ui.postDelayed(this, 1500)
        }
    }

    private fun send(cmd: ByteArray) {
        val g = gatt ?: return
        val w = writeChar ?: return
        w.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        w.value = cmd
        g.writeCharacteristic(w)
    }

    // ---------- Protocolo del BMS ----------
    private fun parseFrames() {
        while (true) {
            val start = buf.indexOfFirst { it == 0xDD.toByte() }
            if (start < 0) { buf = ByteArray(0); return }
            if (start > 0) buf = buf.copyOfRange(start, buf.size)
            if (buf.size < 4) return
            val len = buf[3].toInt() and 0xFF
            val total = len + 7
            if (buf.size < total) return
            val frame = buf.copyOfRange(0, total)
            buf = buf.copyOfRange(total, buf.size)
            if (frame[total - 1] != 0x77.toByte()) continue
            var sum = 0
            for (i in 2 until total - 3) sum += frame[i].toInt() and 0xFF
            val chk = ((0x10000 - sum) and 0xFFFF)
            val got = ((frame[total - 3].toInt() and 0xFF) shl 8) or (frame[total - 2].toInt() and 0xFF)
            if (chk != got) continue
            if (frame[2].toInt() != 0) continue
            val d = frame.copyOfRange(4, 4 + len)
            when (frame[1].toInt() and 0xFF) {
                0x03 -> if (len >= 23) handleBasic(d)
                0x04 -> handleCells(d)
            }
        }
    }

    private fun u16(d: ByteArray, i: Int) = ((d[i].toInt() and 0xFF) shl 8) or (d[i + 1].toInt() and 0xFF)

    private fun handleBasic(d: ByteArray) {
        val volt = u16(d, 0) / 100.0
        val amp = u16(d, 2).toShort().toInt() / 100.0
        val cycles = u16(d, 8)
        val bal = u16(d, 12) != 0 || u16(d, 14) != 0
        val prot = u16(d, 16)
        val soc = d[19].toInt() and 0xFF
        val ntc = d[22].toInt() and 0xFF
        val temps = ArrayList<String>()
        for (k in 0 until ntc) {
            if (23 + 2 * k + 1 < d.size) {
                temps.add(String.format("%.0f", (u16(d, 23 + 2 * k) - 2731) / 10.0))
            }
        }
        val watt = volt * amp
        val mode = if (amp > 0.05) "carga" else if (amp < -0.05) "descarga" else "reposo"
        runOnUiThread {
            tvSoc.text = "$soc %"
            tvSoc.setTextColor(if (soc < 15) Color.RED else if (soc < 30) Color.YELLOW else Color.rgb(120, 200, 80))
            tvVolt.text = String.format("%.2f V", volt)
            tvAmp.text = String.format("%.1f A (%s)", Math.abs(amp), mode)
            tvWatt.text = String.format("%.0f W", Math.abs(watt))
            tvTemp.text = temps.joinToString(" / ") + " C"
            val extra = (if (bal) "  | balanceando" else "") + (if (prot != 0) "  | PROTECCION ACTIVA" else "")
            tvStatus.text = "BMS: conectado | ciclos: $cycles$extra"
        }
    }

    private fun handleCells(d: ByteArray) {
        val n = d.size / 2
        val mv = IntArray(n) { u16(d, it * 2) }
        if (mv.isEmpty()) return
        val mn = mv.min()
        val mx = mv.max()
        val diff = mx - mn
        runOnUiThread {
            for (i in 0 until minOf(n, cellViews.size)) {
                val t = cellViews[i]
                t.text = String.format("%d\n%.3f V", i + 1, mv[i] / 1000.0)
                t.setTextColor(
                    if (mv[i] == mn) Color.rgb(255, 165, 0)
                    else if (mv[i] == mx) Color.CYAN
                    else Color.WHITE
                )
            }
            tvDelta.text = "Diferencia entre celdas: $diff mV"
            tvDelta.setTextColor(if (diff < 20) Color.rgb(120, 200, 80) else if (diff < 50) Color.YELLOW else Color.RED)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        wantConnected = false
        ui.removeCallbacksAndMessages(null)
        try { lm?.removeUpdates(locListener) } catch (e: Exception) {}
        gatt?.close()
    }
}
