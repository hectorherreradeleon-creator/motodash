package com.moto.dash

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.UUID

@Suppress("DEPRECATION")
@SuppressLint("MissingPermission")
class MainActivity : Activity() {

    companion object {
        val SVC: UUID = UUID.fromString("0000ff00-0000-1000-8000-00805f9b34fb")
        val CH_NOTIFY: UUID = UUID.fromString("0000ff01-0000-1000-8000-00805f9b34fb")
        val CH_WRITE: UUID = UUID.fromString("0000ff02-0000-1000-8000-00805f9b34fb")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        val CMD_BASIC = byteArrayOf(0xDD.toByte(), 0xA5.toByte(), 0x03, 0x00, 0xFF.toByte(), 0xFD.toByte(), 0x77)
        val CMD_CELLS = byteArrayOf(0xDD.toByte(), 0xA5.toByte(), 0x04, 0x00, 0xFF.toByte(), 0xFC.toByte(), 0x77)
        const val REQ_PERM = 10
    }

    private val ui = Handler(Looper.getMainLooper())

    private val C_BG = Color.parseColor("#0B0F1A")
    private val C_CARD = Color.parseColor("#151B2B")
    private val C_TILE = Color.parseColor("#1F2740")
    private val C_TEXT = Color.parseColor("#F1F5F9")
    private val C_MUTED = Color.parseColor("#8A94A8")
    private val C_LIME = Color.parseColor("#A3E635")
    private val C_CYAN = Color.parseColor("#22D3EE")
    private val C_ORANGE = Color.parseColor("#FB923C")
    private val C_YELLOW = Color.parseColor("#FACC15")
    private val C_RED = Color.parseColor("#F87171")

    private lateinit var dot: View
    private lateinit var tvStatus: TextView
    private lateinit var tvSpeed: TextView
    private lateinit var tvTrip: TextView
    private lateinit var tvMax: TextView
    private lateinit var tvSoc: TextView
    private lateinit var tvCycles: TextView
    private lateinit var barFill: View
    private lateinit var barRest: View
    private lateinit var tvVolt: TextView
    private lateinit var tvVoltSub: TextView
    private lateinit var tvAmp: TextView
    private lateinit var tvAmpSub: TextView
    private lateinit var tvWatt: TextView
    private lateinit var tvWattSub: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvTempSub: TextView
    private lateinit var tvDelta: TextView
    private val cellVal = ArrayList<TextView>()

    private var lm: LocationManager? = null
    private var prevLoc: Location? = null
    private var tripMeters = 0f
    private var maxKmh = 0f
    private var gpsStarted = false

    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var connected = false
    private var wantConnected = false
    private var buf = ByteArray(0)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }

    private fun lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(C_CARD, 20)
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun hrow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun statCard(row: LinearLayout, title: String, l: Int, r: Int): Array<TextView> {
        val box = card()
        box.layoutParams = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, l, 0, r, 0)
        val t = tv(12f, C_MUTED); t.text = title
        val v = tv(24f, C_TEXT, true); v.text = "--"
        val s = tv(12f, C_MUTED); s.text = " "
        box.addView(t); box.addView(v); box.addView(s)
        row.addView(box)
        return arrayOf(v, s)
    }

    private fun miniStat(row: LinearLayout, label: String): TextView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val t = tv(12f, C_MUTED); t.text = label
        val v = tv(18f, C_TEXT, true)
        box.addView(t); box.addView(v)
        row.addView(box)
        return v
    }

    private fun setStatus(text: String, color: Int) {
        tvStatus.text = text
        (dot.background as GradientDrawable).setColor(color)
    }

    private fun setBar(soc: Int, color: Int) {
        barFill.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, soc.toFloat())
        barRest.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, (100 - soc).toFloat())
        (barFill.background as GradientDrawable).setColor(color)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(24))
            setBackgroundColor(C_BG)
        }
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C_BG)
        scroll.addView(root)
        setContentView(scroll)

        // Encabezado
        val header = hrow()
        header.addView(tv(20f, C_TEXT, true).apply {
            text = "MotoDash"
            layoutParams = lp(0, WRAP, 1f)
        })
        dot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(C_MUTED) }
            layoutParams = lp(dp(10), dp(10), 0f, 0, 0, 8, 0)
        }
        tvStatus = tv(13f, C_MUTED).apply { text = "Sin conectar" }
        header.addView(dot)
        header.addView(tvStatus)
        root.addView(header, lp(MATCH, WRAP, 0f, 4, 0, 4, 12))

        // Velocidad
        val hero = card()
        tvSpeed = tv(120f, C_TEXT).apply {
            text = "0"
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            includeFontPadding = false
        }
        hero.addView(tvSpeed, lp(MATCH, WRAP))
        hero.addView(tv(15f, C_MUTED).apply { text = "km/h"; gravity = Gravity.CENTER }, lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
        val tripRow = hrow()
        tvTrip = miniStat(tripRow, "Viaje"); tvTrip.text = "0.00 km"
        tvMax = miniStat(tripRow, "Máxima"); tvMax.text = "0 km/h"
        tripRow.addView(tv(13f, C_TEXT, true).apply {
            text = "REINICIAR"
            background = rounded(C_TILE, 12)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener {
                tripMeters = 0f; prevLoc = null; maxKmh = 0f
                tvTrip.text = "0.00 km"; tvMax.text = "0 km/h"
            }
        })
        hero.addView(tripRow, lp(MATCH, WRAP))
        root.addView(hero, lp(MATCH, WRAP))

        // Bateria
        val bat = card()
        val batTop = hrow()
        tvSoc = tv(44f, C_LIME, true).apply { text = "-- %"; layoutParams = lp(0, WRAP, 1f) }
        tvCycles = tv(13f, C_MUTED).apply { text = "Batería"; gravity = Gravity.END }
        batTop.addView(tvSoc); batTop.addView(tvCycles)
        bat.addView(batTop, lp(MATCH, WRAP))
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(C_TILE, 6)
        }
        barFill = View(this).apply {
            background = rounded(C_LIME, 6)
            layoutParams = LinearLayout.LayoutParams(0, MATCH, 0f)
        }
        barRest = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, MATCH, 100f) }
        bar.addView(barFill); bar.addView(barRest)
        bat.addView(bar, lp(MATCH, dp(12), 0f, 0, 8, 0, 0))
        root.addView(bat, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        // Datos
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val volt = statCard(r1, "VOLTAJE", 0, 5); tvVolt = volt[0]; tvVoltSub = volt[1]
        val amp = statCard(r1, "CORRIENTE", 5, 0); tvAmp = amp[0]; tvAmpSub = amp[1]
        root.addView(r1, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val watt = statCard(r2, "POTENCIA", 0, 5); tvWatt = watt[0]; tvWattSub = watt[1]
        val temp = statCard(r2, "TEMPERATURA", 5, 0); tvTemp = temp[0]; tvTemp.textSize = 20f; tvTempSub = temp[1]
        root.addView(r2, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        // Celdas
        val cells = card()
        val cHead = hrow()
        cHead.addView(tv(15f, C_TEXT, true).apply { text = "Celdas"; layoutParams = lp(0, WRAP, 1f) })
        tvDelta = tv(13f, C_MUTED).apply { text = "Diferencia --" }
        cHead.addView(tvDelta)
        cells.addView(cHead, lp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        var idx = 0
        for (r in 0 until 5) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 4) {
                idx++
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    background = rounded(C_TILE, 12)
                    setPadding(0, dp(7), 0, dp(7))
                }
                tile.addView(tv(10f, C_MUTED).apply { text = "$idx"; gravity = Gravity.CENTER })
                val v = tv(15f, C_TEXT, true).apply { text = "--"; gravity = Gravity.CENTER }
                tile.addView(v)
                cellVal.add(v)
                row.addView(tile, lp(0, WRAP, 1f, 3, 3, 3, 3))
            }
            cells.addView(row, lp(MATCH, WRAP))
        }
        val legend = hrow()
        legend.addView(tv(12f, C_CYAN).apply { text = "● más alta" })
        legend.addView(tv(12f, C_ORANGE).apply { text = "● más baja" }, lp(WRAP, WRAP, 0f, 14, 0, 0, 0))
        cells.addView(legend, lp(MATCH, WRAP, 0f, 4, 6, 0, 0))
        root.addView(cells, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        // Boton
        root.addView(tv(15f, Color.parseColor("#0B0F1A"), true).apply {
            text = "Buscar / elegir BMS"
            gravity = Gravity.CENTER
            background = rounded(C_LIME, 16)
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener { scanAndChoose() }
        }, lp(MATCH, WRAP, 0f, 0, 14, 0, 0))

        if (hasAllPermissions()) {
            startGps()
            connectSaved()
        } else {
            requestPermissions(neededPermissions(), REQ_PERM)
        }
    }

    // ---------- Permisos ----------
    private fun neededPermissions(): Array<String> {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_SCAN)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        return l.toTypedArray()
    }

    private fun hasAllPermissions(): Boolean =
        neededPermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasAllPermissions()) {
            startGps()
            connectSaved()
        } else {
            Toast.makeText(this, "Faltan permisos (ubicacion y Bluetooth)", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- GPS ----------
    private val locListener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            val kmh = if (loc.hasSpeed()) loc.speed * 3.6f else 0f
            val shown = if (kmh < 1.5f) 0f else kmh
            tvSpeed.text = String.format("%.0f", shown)
            if (shown > maxKmh) {
                maxKmh = shown
                tvMax.text = String.format("%.0f km/h", maxKmh)
            }
            val p = prevLoc
            if (p != null && loc.accuracy < 30f && kmh >= 2f) {
                tripMeters += p.distanceTo(loc)
            }
            prevLoc = loc
            tvTrip.text = String.format("%.2f km", tripMeters / 1000f)
        }
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private fun startGps() {
        if (gpsStarted) return
        val m = getSystemService(LOCATION_SERVICE) as LocationManager
        lm = m
        if (!m.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(this, "Activa el GPS del telefono", Toast.LENGTH_LONG).show()
        }
        m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener)
        gpsStarted = true
    }

    // ---------- Bluetooth: busqueda ----------
    private fun adapter() = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private fun scanAndChoose() {
        if (!hasAllPermissions()) {
            requestPermissions(neededPermissions(), REQ_PERM)
            return
        }
        val ad = adapter()
        if (ad == null || !ad.isEnabled) {
            Toast.makeText(this, "Enciende el Bluetooth", Toast.LENGTH_LONG).show()
            return
        }
        val scanner = ad.bluetoothLeScanner
        val found = LinkedHashMap<String, Triple<String, Int, String>>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, r: ScanResult) {
                val name = r.scanRecord?.deviceName ?: r.device.name ?: "(sin nombre)"
                found[r.device.address] = Triple(name, r.rssi, r.device.address)
            }
        }
        setStatus("Buscando…", C_YELLOW)
        scanner.startScan(cb)
        ui.postDelayed({
            scanner.stopScan(cb)
            if (connected) setStatus("Conectado", C_LIME) else setStatus("Sin conectar", C_MUTED)
            val list = found.values.sortedByDescending { it.second }
            if (list.isEmpty()) {
                Toast.makeText(this, "No se encontro nada. Cierra Bat BMS e intenta otra vez", Toast.LENGTH_LONG).show()
            } else {
                val labels = list.map { "${it.first}  (${it.third})  ${it.second} dBm" }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("Elige tu BMS")
                    .setItems(labels) { _, i ->
                        getSharedPreferences("moto", 0).edit().putString("addr", list[i].third).apply()
                        connect(list[i].third)
                    }
                    .show()
            }
        }, 6000)
    }

    // ---------- Bluetooth: conexion ----------
    private fun connectSaved() {
        val a = getSharedPreferences("moto", 0).getString("addr", null)
        if (a != null) connect(a)
    }

    private fun connect(addr: String) {
        val ad = adapter() ?: return
        wantConnected = true
        gatt?.close()
        connected = false
        buf = ByteArray(0)
        setStatus("Conectando…", C_YELLOW)
        val dev = ad.getRemoteDevice(addr)
        gatt = dev.connectGatt(this, false, gattCb, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connected = false
                g.close()
                runOnUiThread { setStatus("Desconectado", C_RED) }
                if (wantConnected) {
                    ui.postDelayed({ if (wantConnected && !connected) connectSaved() }, 4000)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val svc = g.getService(SVC)
            val n = svc?.getCharacteristic(CH_NOTIFY)
            val w = svc?.getCharacteristic(CH_WRITE)
            if (n == null || w == null) {
                runOnUiThread { setStatus("No compatible", C_RED) }
                return
            }
            writeChar = w
            g.setCharacteristicNotification(n, true)
            val d = n.getDescriptor(CCCD)
            d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(d)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            connected = true
            runOnUiThread { setStatus("Conectado", C_LIME) }
            ui.post(poll)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val data = c.value ?: return
            synchronized(this@MainActivity) {
                buf += data
                parseFrames()
            }
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            if (!connected) return
            send(CMD_BASIC)
            ui.postDelayed({ send(CMD_CELLS) }, 350)
            ui.postDelayed(this, 1500)
        }
    }

    private fun send(cmd: ByteArray) {
        val g = gatt ?: return
        val w = writeChar ?: return
        w.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        w.value = cmd
        g.writeCharacteristic(w)
    }

    // ---------- Protocolo del BMS ----------
    private fun parseFrames() {
        while (true) {
            val start = buf.indexOfFirst { it == 0xDD.toByte() }
            if (start < 0) { buf = ByteArray(0); return }
            if (start > 0) buf = buf.copyOfRange(start, buf.size)
            if (buf.size < 4) return
            val len = buf[3].toInt() and 0xFF
            val total = len + 7
            if (buf.size < total) return
            val frame = buf.copyOfRange(0, total)
            buf = buf.copyOfRange(total, buf.size)
            if (frame[total - 1] != 0x77.toByte()) continue
            var sum = 0
            for (i in 2 until total - 3) sum += frame[i].toInt() and 0xFF
            val chk = ((0x10000 - sum) and 0xFFFF)
            val got = ((frame[total - 3].toInt() and 0xFF) shl 8) or (frame[total - 2].toInt() and 0xFF)
            if (chk != got) continue
            if (frame[2].toInt() != 0) continue
            val d = frame.copyOfRange(4, 4 + len)
            when (frame[1].toInt() and 0xFF) {
                0x03 -> if (len >= 23) handleBasic(d)
                0x04 -> handleCells(d)
            }
        }
    }

    private fun u16(d: ByteArray, i: Int) = ((d[i].toInt() and 0xFF) shl 8) or (d[i + 1].toInt() and 0xFF)

    private fun handleBasic(d: ByteArray) {
        val volt = u16(d, 0) / 100.0
        val amp = u16(d, 2).toShort().toInt() / 100.0
        val cycles = u16(d, 8)
        val bal = u16(d, 12) != 0 || u16(d, 14) != 0
        val prot = u16(d, 16)
        val soc = d[19].toInt() and 0xFF
        val ntc = d[22].toInt() and 0xFF
        val temps = ArrayList<String>()
        for (k in 0 until ntc) {
            if (23 + 2 * k + 1 < d.size) {
                temps.add(String.format("%.0f", (u16(d, 23 + 2 * k) - 2731) / 10.0))
            }
        }
        val watt = volt * amp
        val ncell = d[21].toInt() and 0xFF
        val mode = if (amp > 0.05) "Cargando" else if (amp < -0.05) "Descargando" else "En reposo"
        val modeColor = if (amp > 0.05) C_LIME else if (amp < -0.05) C_ORANGE else C_MUTED
        val socColor = if (soc < 15) C_RED else if (soc < 30) C_YELLOW else C_LIME
        runOnUiThread {
            tvSoc.text = "$soc %"
            tvSoc.setTextColor(socColor)
            setBar(soc, socColor)
            tvCycles.text = "$cycles ciclos" + (if (bal) "\nbalanceando" else "")
            tvVolt.text = String.format("%.2f V", volt)
            tvVoltSub.text = "$ncell celdas"
            tvAmp.text = String.format("%.1f A", Math.abs(amp))
            tvAmpSub.text = mode
            tvAmpSub.setTextColor(modeColor)
            tvWatt.text = String.format("%.0f W", Math.abs(watt))
            tvWattSub.text = if (amp > 0.05) "hacia la batería" else if (amp < -0.05) "desde la batería" else "sin consumo"
            tvWattSub.setTextColor(modeColor)
            tvTemp.text = temps.joinToString(" / ") + " °C"
            tvTempSub.text = "$ntc sensores"
            if (prot != 0) setStatus("Protección activa", C_RED) else setStatus("Conectado", C_LIME)
        }
    }

    private fun handleCells(d: ByteArray) {
        val n = d.size / 2
        val mv = IntArray(n) { u16(d, it * 2) }
        if (mv.isEmpty()) return
        val mn = mv.min()
        val mx = mv.max()
        val diff = mx - mn
        runOnUiThread {
            for (i in 0 until minOf(n, cellVal.size)) {
                val t = cellVal[i]
                t.text = String.format("%.3f", mv[i] / 1000.0)
                t.setTextColor(if (mv[i] == mn) C_ORANGE else if (mv[i] == mx) C_CYAN else C_TEXT)
            }
            tvDelta.text = "Diferencia $diff mV"
            tvDelta.setTextColor(if (diff < 20) C_LIME else if (diff < 50) C_YELLOW else C_RED)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        wantConnected = false
        ui.removeCallbacksAndMessages(null)
        try { lm?.removeUpdates(locListener) } catch (e: Exception) {}
        gatt?.close()
    }
}
